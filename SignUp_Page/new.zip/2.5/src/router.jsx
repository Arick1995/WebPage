import LandingPage from 'Source/components/LandingPage.jsx'
import SignIn from 'Source/components/SignIn.jsx'
import SignUp from 'Source/components/SignUp.jsx'


const routes = [
    {
        path: '/',
        exact: true,
        component: LandingPage
    },
    {
        path: '/signin',
        exact: true,
        component: SignIn
    },
    {
        path: '/signup',
        exact: true,
        component: SignUp
    },

]

export default routes
