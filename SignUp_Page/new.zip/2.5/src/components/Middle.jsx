import React from 'react'
import ReactDOM from 'react-dom'

class Middle extends React.Component {
	render() {
		return (
			<div className="ui container">
				<div className="ui basic center aligned segment">
					<h1>TITLE</h1>
					<p>描述</p>
				</div>
				<div className="ui stackable two column grid">
					<div className="column">
						<div className="ui basic left aligned segment">
							<p>驅逐的特性是著有高迴避、高航速(這遊戲迴避並不等於航速，迴避自然是迴避對方攻擊，而航速則是小人的移動速度)</p>
						</div>
					</div>
					<div className="column">
						<div className="ui basic left aligned segment">
							<p>高迴避再隊伍可以增加被伏擊的迴避率。</p>
						</div>
					</div>
				</div>
				<div className="ui basic very padded center aligned segment">
					<button className="ui secondary basic button" data-tooltip="教你別按你還想按" data-position="top center">請別按我</button>
				</div>
			</div>
		)
	}
}

export default Middle
