import React from 'react'
import ReactDOM from 'react-dom'

import Header from 'Source/components/Header.jsx'
import Footer from 'Source/components/Footer.jsx'
import SigninWriter from 'Source/components/SigninWriter.jsx'


class SignIn extends React.Component {
	constructor(props, context) {
		super(props, context)

		this.state = {}
	}

	render() {
		return (
			<div>
				<Header serviceName={'Home'} />

				<section className="ui basic vertical segment signin-header">
					<div className="ui container">
						<div className="ui basic very padded left aligned segment">
							<h1>Sign In</h1>
						</div>
					</div>
				</section>

                <div className="ui divider hidden"></div>

                <section className="ui basic segment">
                    <div className="ui container">
                        <div className="ui centered grid">
                            <div className="eleven wide one column computer only tablet only row">
                                <div className="column">
                                    <SigninWriter />
                                </div>
                            </div>

                            <div className="one column mobile only row">
                                <div className="column">
                                    <SigninWriter />
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

				<Footer serviceName={'Home'} />
			</div>
		)
	}
}

export default SignIn
