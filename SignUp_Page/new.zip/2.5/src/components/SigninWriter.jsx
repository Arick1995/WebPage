import React from 'react'
import ReactDOM from 'react-dom'

class SigninWriter extends React.Component {
    submit = () => {
        var account = this.refs.account.value
        var password = this.refs.password.value
        }

	render() {
		return (
			<div className="ui basic vertical segment">
				<div className="ui divider hidden"></div>
				<div className="ui form">
					<div className="field">
						<label>Account</label>
						<input ref="account" type="text" />
					</div>
					<div className="field">
						<label>Password</label>
						<input ref="password" type="password" />
					</div>
					<button className="ui secondary basic button" onClick={this.submit}>Submit</button>
				</div>
			</div>
		);
	}
}

export default  SigninWriter
