import React from 'react'
import ReactDOM from 'react-dom'

import Card from 'Source/components/Card.jsx'

// Section image
import apple from 'Source/images/61097279_p0.jpg'

class Test extends React.Component {
	constructor(props, context) {
		super(props, context)

        this.state = {
			cardTitle: '放棄思考',
			cardContent: '挖咖哩瑪士達'
        }
	}

	render() {
		return (
			<div className="ui container">
				<div className="ui stackable two column grid">
					<div className="column">
						<img className="ui fluid image" src={apple} />
					</div>
					<Card color="#33FFFF" cardTitle={this.state.cardTitle} cardContent={this.state.cardContent} />
				</div>
			</div>
		)
	}
}

export default Test