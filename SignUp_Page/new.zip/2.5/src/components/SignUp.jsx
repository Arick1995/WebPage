import React from 'react'
import ReactDOM from 'react-dom'

import Header from 'Source/components/Header.jsx'
import Footer from 'Source/components/Footer.jsx'
import SignUpWriter from 'Source/components/SignUpWriter.jsx'



class SignUp extends React.Component {
	constructor(props, context) {
		super(props, context)

		this.state = {}
	}

	render() {
		return (
			<div>
				<Header serviceName={'Home'} />

				<section className="ui basic vertical segment signup-header">
					<div className="ui container">
						<div className="ui basic very padded left aligned segment">
							<h1>Sign Up</h1>
						</div>
					</div>
				</section>

                <div className="ui divider hidden"></div>

                <section className="ui basic segment">
                    <div className="ui container">
                        <div className="ui centered grid">
                            <div className="eleven wide one column computer only tablet only row">
                                <div className="column">
                                    <SignUpWriter />
                                </div>
                            </div>

                            <div className="one column mobile only row">
                                <div className="column">
                                    <SignUpWriter />
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

				<Footer serviceName={'Home'} />
			</div>
		)
	}
}

export default SignUp
