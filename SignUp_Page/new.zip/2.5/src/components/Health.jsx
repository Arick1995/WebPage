import React from 'react'
import ReactDOM from 'react-dom'

import Card from 'Source/components/Card.jsx'

// Section image
import sketch from 'Source/images/63966667_p0.jpg'

class Health extends React.Component {
	constructor(props, context) {
		super(props, context)

        this.state = {
			cardTitle: '標語我想不到',
			cardContent: '薯泥馬薯'
        }
	}

	render() {
		return (
			<div className="ui container">
				<div className="ui stackable two column grid">
					<div className="column">
						<img className="ui fluid image" src={sketch} />
					</div>
					<Card color="#91af59" cardTitle={this.state.cardTitle} cardContent={this.state.cardContent} />
				</div>
			</div>
		)
	}
}

export default Health
