import React from 'react'
import ReactDOM from 'react-dom'

class SignUpWriter extends React.Component {
    submit = () => {
        var email = this.refs.email.value
        var password = this.refs.password.value
        var passwordconfirm = this.refs.passwordconfirm.value
        var name = this.refs.name.value
        var sex = this.refs.sex.value
        var birthday = this.refs.birthday.value
        var Career = this.refs.Career.value
        var phone = this.refs.phone.value
        var address = this.refs.address.value
        }

	render() {
		return (
			<div className="ui basic vertical segment">
				<div className="ui divider hidden"></div>
				<div className="ui form">
					<div className="field">
						<label>電子信箱</label>
						<input ref="email" type="text" />
					</div>
					<div className="field">
						<label>密碼</label>
						<input ref="password" type="text" />
					</div>
					<div className="field">
						<label>密碼確認</label>
						<input ref="passwordconfirm" type="text" />
					</div>
					<div className="field">
						<label>姓名</label>
						<input ref="name" type="text" />
					</div>
					<div className="field">
						<label>性別</label>
						<input type="radio" name="sex" value="Male" ref="sex"/> 男
						&nbsp;&nbsp;
						<input type="radio" name="sex" value="Female" ref="sex"/> 女						
					</div>
					<div className="field">
						<label for="birthday">生日</label>
						<input type="date" id="birthday" placeholder="2014-09-18" ref="birthday"/>
					</div>
					<div className="field">
						<label>職業</label>
						<input ref="Career" type="text" />
					</div>
					<div className="field">
						<label>電話號碼</label>
						<input ref="phone" type="text" />
					</div>
					<div className="field">
						<label>地址</label>
						<input ref="address" type="text" />
					</div>


					<button className="ui secondary basic button" onClick={this.submit}>Submit</button>
				</div>
			</div>
		);
	}
}

export default  SignUpWriter
