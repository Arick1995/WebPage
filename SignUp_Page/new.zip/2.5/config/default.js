module.exports = {
	'service': {
		'name': 'React',
		'external_url': 'http://localhost:3001'
	},
	'server': {
		'port': 3001
	}
};
